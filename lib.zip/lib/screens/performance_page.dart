import 'package:cet_verse/ui/components/ProgressPage.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cet_verse/core/auth/AuthProvider.dart';

class PerformancePage extends StatefulWidget {
  const PerformancePage({super.key});

  @override
  _PerformancePageState createState() => _PerformancePageState();
}

class _PerformancePageState extends State<PerformancePage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _physicsAnimation;
  late Animation<double> _chemistryAnimation;
  late Animation<double> _mathsAnimation;

  double physicsPerformance = 75;
  double chemistryPerformance = 60;
  double mathsPerformance = 80;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    );

    _physicsAnimation = Tween<double>(begin: 0, end: physicsPerformance / 100)
        .animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
    _chemistryAnimation = Tween<double>(
            begin: 0, end: chemistryPerformance / 100)
        .animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
    _mathsAnimation = Tween<double>(begin: 0, end: mathsPerformance / 100)
        .animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));

    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          border: Border.all(
              color: const Color.fromARGB(44, 158, 158, 158), width: 5),
        ),
        child: Column(
          children: [
            _buildProgressBar(
              label: "Physics Progress",
              percentage: physicsPerformance,
              animation: _physicsAnimation,
              bgColor: const Color(0xFFE6F2FC),
              progressColor: Colors.blue,
              percentageColor: Colors.blue,
            ),
            const SizedBox(height: 8),
            _buildProgressBar(
              label: "Chemistry Progress",
              percentage: chemistryPerformance,
              animation: _chemistryAnimation,
              bgColor: const Color(0xFFFFF7E6),
              progressColor: Colors.orange,
              percentageColor: Colors.orange,
            ),
            const SizedBox(height: 8),
            _buildProgressBar(
              label: "Mathematics Progress",
              percentage: mathsPerformance,
              animation: _mathsAnimation,
              bgColor: const Color(0xFFF2FCF2),
              progressColor: Colors.green,
              percentageColor: Colors.green,
            ),
            const SizedBox(height: 20),
            _buildAnalysisButton(),
          ],
        ),
      ),
    );
  }

  Widget _buildProgressBar({
    required String label,
    required double percentage,
    required Animation<double> animation,
    required Color bgColor,
    required Color progressColor,
    required Color percentageColor,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(label,
                  style: const TextStyle(
                      fontSize: 14, fontWeight: FontWeight.w600)),
              Text(
                "${percentage.toInt()}%",
                style: TextStyle(
                  color: percentageColor,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          AnimatedBuilder(
            animation: animation,
            builder: (context, child) {
              return LinearProgressIndicator(
                value: animation.value,
                backgroundColor: Colors.grey.shade300,
                valueColor: AlwaysStoppedAnimation(progressColor),
                minHeight: 8,
                borderRadius: BorderRadius.circular(20),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildAnalysisButton() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF2196F3), Color(0xFFFFC107)],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
      ),
      child: MaterialButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const ProgressPage()),
          );
        },
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
        child: const Text(
          "View Your Analysis",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}
