import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tex/flutter_tex.dart';
import 'package:provider/provider.dart';
import 'package:get_phone_number/get_phone_number.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';

import 'package:cet_verse/core/auth/AuthProvider.dart';
import 'package:cet_verse/screens/dashboard_page.dart';
import 'package:cet_verse/core/auth/phone_auth_screen.dart';
import 'package:cet_verse/core/config/firebase_options.dart';

class FlashScreen extends StatefulWidget {
  const FlashScreen({super.key});
  @override
  State<FlashScreen> createState() => _FlashScreenState();
}

class _FlashScreenState extends State<FlashScreen> {
  final PageController _pageController = PageController();
  int _currentPage = 0;
  Timer? _timer;
  final _slideImages = const ['assets/stude1.jpg', 'assets/stude2.jpg'];

  @override
  void initState() {
    super.initState();

    // Start lightweight UI work immediately
    _startAutoSlides();

    // Kick heavy stuff AFTER first frame (doesn't block first paint)
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      _lateStartTeX();
      await _checkUserLogin(); // navigate when ready
    });
  }

  void _startAutoSlides() {
    _timer = Timer.periodic(const Duration(seconds: 3), (_) {
      if (!mounted) return;
      _currentPage = (_currentPage + 1) % _slideImages.length;
      _pageController.animateToPage(
        _currentPage,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeIn,
      );
      setState(() {});
    });
  }

  Future<void> _lateStartTeX() async {
    if (!kIsWeb) {
      try {
        await TeXRenderingServer.start();
      } catch (e) {
        debugPrint('TeX start failed: $e');
      }
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pageController.dispose();
    super.dispose();
  }

  Future<void> _ensureFirebase() async {
    if (Firebase.apps.isEmpty) {
      try {
        await Firebase.initializeApp(
          options: DefaultFirebaseOptions.currentPlatform,
        );
      } catch (e) {
        debugPrint('Firebase init error: $e');
      }
    }
  }

  Future<void> _checkUserLogin() async {
    await _ensureFirebase();

    final auth = context.read<AuthProvider>();

    // Run in parallel: restore session + try reading phone number
    final restoreF = auth.restoreSession();
    final phoneF = GetPhoneNumber()
        .get()
        .timeout(const Duration(seconds: 3))
        .then<String?>((raw) {
      if (raw == null) return null;
      // keep only digits, then strip leading 0/91/+91 safely
      final digits = raw.replaceAll(RegExp(r'[^0-9]'), '');
      return digits.replaceFirst(RegExp(r'^(?:0|91)?'), '');
    }).catchError((_) => null);

    await restoreF;

    if (!mounted) return;

    // If we already have a user, go directly
    if (auth.currentUser != null) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const DashboardPage()),
      );
      return;
    }

    // Try Firestore lookup with detected phone (if any)
    final phone = await phoneF;
    if (phone != null && phone.isNotEmpty) {
      try {
        final userDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(phone)
            .get();

        if (!mounted) return;

        if (userDoc.exists) {
          await auth.fetchUserData(phone);
          if (!mounted) return;
          Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (_) => const DashboardPage()),
          );
          return;
        }
      } catch (e) {
        debugPrint('User lookup error: $e');
      }
    }

    // Fallback → PhoneAuth
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const PhoneAuthScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset('assets/cetverse.png', width: 250, height: 250),
            const SizedBox(height: 20),
            const CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.black),
              strokeWidth: 2.5,
            ),
            const SizedBox(height: 30),
            SizedBox(
              height: 200,
              child: PageView.builder(
                controller: _pageController,
                itemCount: _slideImages.length,
                onPageChanged: (i) => setState(() => _currentPage = i),
                itemBuilder: (_, i) => Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.asset(_slideImages[i], fit: BoxFit.cover),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                _slideImages.length,
                (i) => Container(
                  width: 8,
                  height: 8,
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _currentPage == i
                        ? Colors.black
                        : Colors.grey.withOpacity(0.4),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
