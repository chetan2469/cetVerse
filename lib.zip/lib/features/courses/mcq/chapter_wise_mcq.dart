import 'package:cet_verse/features/courses/mcq/add_mcq.dart';
import 'package:cet_verse/features/courses/mcq/display_mcq.dart';
import 'package:cet_verse/features/courses/mcq/update_mcq.dart';
import 'package:cet_verse/ui/components/my_drawer.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cet_verse/ui/theme/constants.dart';

class ChapterWiseMcq extends StatefulWidget {
  final String level; // e.g. "11th Standard"
  final String subject; // e.g. "Biology"
  final String chapter; // e.g. "Diversity in Organisms"

  const ChapterWiseMcq(
      {super.key,
      required this.level,
      required this.subject,
      required this.chapter});

  @override
  _ChapterWiseMcqState createState() => _ChapterWiseMcqState();
}

class _ChapterWiseMcqState extends State<ChapterWiseMcq> {
  bool _isLoading = true;
  List<Map<String, dynamic>> _allMcqs = [];

  @override
  void initState() {
    super.initState();
    _fetchMcqs();
  }

  /// Fetch all MCQs from Firestore for the given level/subject/chapter
  Future<void> _fetchMcqs() async {
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('levels')
          .doc(widget.level)
          .collection('subjects')
          .doc(widget.subject)
          .collection('chapters')
          .doc(widget.chapter)
          .collection('mcqs')
          .get();

      setState(() {
        _allMcqs = snapshot.docs.map((doc) {
          final data = doc.data();
          return {
            ...data,
            'docId': doc.id,
          };
        }).toList();
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error loading MCQs: $e")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final scaffoldKey = GlobalKey<ScaffoldState>();

    return SafeArea(
      child: Scaffold(
        key: scaffoldKey,
        drawer: const MyDrawer(),
        backgroundColor: AppTheme.scaffoldBackground,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.black),
            onPressed: () => Navigator.pop(context),
          ),
          title: Text(
            "${widget.chapter} MCQs",
            style: AppTheme.subheadingStyle.copyWith(fontSize: 12),
          ),
          backgroundColor: Colors.white,
          elevation: 1,
          actions: [
            IconButton(
              icon: const Icon(Icons.add, color: Colors.black),
              tooltip: "Add New MCQ",
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => AddMCQ(
                      level: widget.level,
                      subject: widget.subject,
                      chapter: widget.chapter,
                    ),
                  ),
                ).then((_) => _fetchMcqs()); // Reload after adding MCQ
              },
            ),
          ],
        ),
        body: _isLoading
            ? const Center(child: CircularProgressIndicator())
            : _allMcqs.isEmpty
                ? const Center(
                    child: Text(
                      "No MCQs found.",
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.white,
                      ),
                    ),
                  )
                : Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: ListView.builder(
                      physics: const BouncingScrollPhysics(),
                      itemCount: _allMcqs.length,
                      itemBuilder: (context, index) {
                        final mcqData = _allMcqs[index];
                        return _buildMCQPreviewCard(mcqData, index + 1);
                      },
                    ),
                  ),
      ),
    );
  }

  /// Builds a preview card for each MCQ
  Widget _buildMCQPreviewCard(Map<String, dynamic> mcq, int number) {
    final questionMap = mcq['question'] as Map<String, dynamic>? ?? {};
    final String questionText = questionMap['text'] ?? "";
    final docId = mcq['docId'] as String;

    return Card(
      elevation: 4,
      color: Colors.white,
      margin: const EdgeInsets.only(bottom: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Q$number.",
                  style: AppTheme.subheadingStyle.copyWith(fontSize: 16),
                ),
                Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.edit),
                      tooltip: "Edit MCQ",
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => UpdateMCQ(
                              level: widget.level,
                              subject: widget.subject,
                              chapter: widget.chapter,
                              mcq: mcq,
                              docId: docId,
                            ),
                          ),
                        ).then((_) => _fetchMcqs());
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.visibility),
                      tooltip: "View MCQ",
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => DisplayMcq(mcq: mcq),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              questionText,
              style: AppTheme.subheadingStyle.copyWith(fontSize: 14),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}
