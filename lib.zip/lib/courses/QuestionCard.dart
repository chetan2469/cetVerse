import 'package:flutter/material.dart';
import 'package:flutter_tex/flutter_tex.dart';

class QuestionCard extends StatefulWidget {
  final int index;
  final Map<String, dynamic> mcq;
  final List<int> userAnswers;
  final bool hasSubmitted;
  final Function(String) onSelectAnswer;
  final Function nextQuestion, prevQuestion;
  final Set<int> reviewedQuestions;
  final Function(int) onToggleReview;

  const QuestionCard({
    super.key,
    required this.index,
    required this.mcq,
    required this.userAnswers,
    required this.hasSubmitted,
    required this.onSelectAnswer,
    required this.reviewedQuestions,
    required this.onToggleReview,
    required this.nextQuestion,
    required this.prevQuestion,
  });

  @override
  State<QuestionCard> createState() => _QuestionCardState();
}

class _QuestionCardState extends State<QuestionCard> {
  int? _selectedOptionIndex;
  bool _isBookmarked = false;

  @override
  void initState() {
    super.initState();
    _updateSelection();
  }

  @override
  void didUpdateWidget(covariant QuestionCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.index != widget.index ||
        oldWidget.userAnswers != widget.userAnswers) {
      _updateSelection();
    }
  }

  void _updateSelection() {
    final originalIndex = widget.userAnswers.indexOf(widget.mcq as int);
    if (originalIndex != -1) {
      _selectedOptionIndex = widget.userAnswers[originalIndex];
    } else {
      _selectedOptionIndex = -1;
    }
    _isBookmarked = widget.reviewedQuestions.contains(widget.index);
  }

  @override
  Widget build(BuildContext context) {
    final questionMap = widget.mcq['question'] as Map<String, dynamic>? ?? {};
    final String questionText = questionMap['text'] ?? 'No question provided.';
    final String questionImage = questionMap['image'] ?? '';

    final optionsMap = widget.mcq['options'] as Map<String, dynamic>? ?? {};
    final Map<String, dynamic> optionA =
        optionsMap['A'] as Map<String, dynamic>? ?? {};
    final Map<String, dynamic> optionB =
        optionsMap['B'] as Map<String, dynamic>? ?? {};
    final Map<String, dynamic> optionC =
        optionsMap['C'] as Map<String, dynamic>? ?? {};
    final Map<String, dynamic> optionD =
        optionsMap['D'] as Map<String, dynamic>? ?? {};

    final String aText = optionA['text'] ?? '';
    final String aImage = optionA['image'] ?? '';
    final String bText = optionB['text'] ?? '';
    final String bImage = optionB['image'] ?? '';
    final String cText = optionC['text'] ?? '';
    final String cImage = optionC['image'] ?? '';
    final String dText = optionD['text'] ?? '';
    final String dImage = optionD['image'] ?? '';

    String finalQuestionText = "<b>Q${widget.index + 1}: </b>$questionText";
    if (questionImage.isNotEmpty) {
      finalQuestionText +=
          '<br/><img src="$questionImage" width="200" height="40"/>';
    }

    String finalAText = aText;
    if (aImage.isNotEmpty) {
      finalAText += '<br/><img src="$aImage" width="200" height="40"/>';
    }
    String finalBText = bText;
    if (bImage.isNotEmpty) {
      finalBText += '<br/><img src="$bImage" width="200" height="40"/>';
    }
    String finalCText = cText;
    if (cImage.isNotEmpty) {
      finalCText += '<br/><img src="$cImage" width="200" height="40"/>';
    }
    String finalDText = dText;
    if (dImage.isNotEmpty) {
      finalDText += '<br/><img src="$dImage" width="200" height="40"/>';
    }

    return GestureDetector(
      onHorizontalDragEnd: (details) {
        if (widget.hasSubmitted) return;
        const double swipeThreshold = 100;
        if (details.primaryVelocity! < -swipeThreshold) {
          widget.nextQuestion();
        } else if (details.primaryVelocity! > swipeThreshold) {
          widget.prevQuestion();
        }
      },
      child: Container(
        margin: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Stack(
          children: [
            ListView(
              physics: const BouncingScrollPhysics(),
              children: [
                TeXView(
                  key: ValueKey("quiz_${widget.index}_${widget.mcq['docId']}"),
                  child: TeXViewColumn(
                    children: [
                      TeXViewDocument(
                        finalQuestionText,
                        style: TeXViewStyle(
                          textAlign: TeXViewTextAlign.left,
                          fontStyle: TeXViewFontStyle(fontSize: 16),
                          padding: TeXViewPadding.all(16),
                        ),
                      ),
                      TeXViewGroup(
                        children: [
                          _buildOption("id_1", "A", finalAText),
                          _buildOption("id_2", "B", finalBText),
                          _buildOption("id_3", "C", finalCText),
                          _buildOption("id_4", "D", finalDText),
                        ],
                        selectedItemStyle: const TeXViewStyle(
                          borderRadius: TeXViewBorderRadius.all(8),
                          border: TeXViewBorder.all(
                            TeXViewBorderDecoration(
                              borderWidth: 2,
                              borderColor: Colors.green,
                            ),
                          ),
                          margin: TeXViewMargin.all(8),
                          backgroundColor: Colors.green,
                          padding: TeXViewPadding.all(10),
                        ),
                        normalItemStyle: const TeXViewStyle(
                          margin: TeXViewMargin.all(8),
                          borderRadius: TeXViewBorderRadius.all(8),
                          border: TeXViewBorder.all(
                            TeXViewBorderDecoration(
                              borderWidth: 1,
                              borderColor: Colors.grey,
                            ),
                          ),
                          backgroundColor: Colors.white,
                          padding: TeXViewPadding.all(10),
                        ),
                        onTap:
                            widget.hasSubmitted ? null : widget.onSelectAnswer,
                      ),
                    ],
                  ),
                  style: const TeXViewStyle(
                    margin: TeXViewMargin.all(10),
                    padding: TeXViewPadding.all(10),
                    borderRadius: TeXViewBorderRadius.all(10),
                    border: TeXViewBorder.all(
                      TeXViewBorderDecoration(
                        borderColor: Colors.grey,
                        borderStyle: TeXViewBorderStyle.solid,
                        borderWidth: 1,
                      ),
                    ),
                    backgroundColor: Colors.white,
                  ),
                  loadingWidgetBuilder: (context) => const Center(
                    child: CircularProgressIndicator(),
                  ),
                  onRenderFinished: (height) {
                    print(
                        'TeXView rendered for question ${widget.index}, height: $height');
                  },
                ),
              ],
            ),
            Positioned(
              top: 8,
              right: 8,
              child: IconButton(
                icon: Icon(
                  Icons.bookmark,
                  color: _isBookmarked
                      ? const Color.fromARGB(255, 228, 210, 42)
                      : Colors.grey,
                  size: 24,
                ),
                onPressed: () {
                  setState(() {
                    _isBookmarked = !_isBookmarked;
                  });
                  widget.onToggleReview(widget.index);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  TeXViewGroupItem _buildOption(String id, String label, String content) {
    final isSelected = _selectedOptionIndex == int.parse(id.split('_')[1]) - 1;

    return TeXViewGroupItem(
      rippleEffect: true,
      id: id,
      child: TeXViewDocument(
        "<b>$label: </b>$content ",
        style: TeXViewStyle(
          padding: const TeXViewPadding.all(12),
          fontStyle: TeXViewFontStyle(
            fontSize: 14,
            fontWeight:
                isSelected ? TeXViewFontWeight.bold : TeXViewFontWeight.normal,
          ),
          backgroundColor: isSelected
              ? const Color.fromARGB(255, 76, 175, 80)
              : Colors.white,
          contentColor: isSelected ? Colors.white : Colors.black,
        ),
      ),
    );
  }
}
